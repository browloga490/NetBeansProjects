/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package trianglearea;

/**
 *
 * @author rrobyn
 */
public class Main {

    public static void main(String[] args) {

    /*Variable Declarations*/

    int base;
    int height;
    int area;

    base = 6;
    height = 4;
    area = base * height / 2;  //Calculates the area of a triangle

    System.out.println("The area of a triangle with a base of" + base + " and a height of " + height + " is " + area + " units squared");

    }

}
