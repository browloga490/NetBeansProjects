/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areaofaroom;

/**
 *
 * @author Logoswego
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String roomName = "Bathroom";
        int length = 9;
        int width = 4;
        int area = length * width;
        System.out.println("The area of the Bathroom is " + area + " m2.");
}
    }

